/**
 * DateDisplay — 날짜 트리거 + DatePickerPopup wrapper
 *
 * ✅ 변경 이력
 *  - [2026-05-04 STEP 2] 신규 생성 — MY PAGE 재설계용
 *
 * 📌 Figma 1:1 반영 (node 449:1771)
 *  · 컨테이너: bg #fff, rounded 12, padding pl 12 pr 16 py 14, gap 6, h 52
 *  · 아이콘: calendar_today 24×24 (Icons.tsx에서 추출)
 *  · 날짜 텍스트: 16 Medium #111, leading normal
 *  · 요일 텍스트: 16 Medium #99A1AF, leading normal
 *  · 표시 형식: "2026년 4월 12일 수요일"
 *
 * 📌 사용 방식
 *   const [from, setFrom] = useState<string>(todayStr())
 *   <DateDisplay value={from} onChange={setFrom} max={to} />
 */

import { useState, useRef } from 'react'
import { CalendarTodayIcon } from './Icons'
import { DatePickerPopup } from './DatePickerPopup'
import { fmtDateFull, dateToObj, DAY_NAMES } from '../../utils/time'

// ─── Props ───────────────────────────────────────────────────────────────────
interface DateDisplayProps {
  value:    string                          // ← YYYY-MM-DD (빈 문자열 허용 — placeholder 표시)
  onChange: (newDate: string) => void
  min?:     string                          // ← 선택 가능 최소 (YYYY-MM-DD)
  max?:     string                          // ← 선택 가능 최대 (YYYY-MM-DD)
  placeholder?: string                      // ← 빈 값일 때 표시 텍스트 (기본 "날짜 선택")
}

// ─── Component ───────────────────────────────────────────────────────────────
export function DateDisplay({
  value, onChange, min, max,
  placeholder = '날짜 선택',
}: DateDisplayProps) {
  const [open, setOpen] = useState(false)
  const triggerRef = useRef<HTMLButtonElement>(null)

  // ── 표시값 계산
  //   value 있음:   "2026년 4월 12일" + "수"
  //   value 없음:   placeholder만 표시, 요일 숨김
  // ← [2026-05-06 Phase 4 사용자 요청] 요일 "수요일" 풀네임 → "수" 단축 (Figma 468:3244 1:1)
  const hasValue   = !!value
  const displayDate = hasValue ? fmtDateFull(value) : placeholder
  const displayDay  = hasValue
    ? DAY_NAMES[dateToObj(value).getDay()]              // ← "수" (이전 "수요일")
    : ''

  return (
    <>
      {/* ── 트리거 버튼 (Figma node 449:1771) ──────────────────────────── */}
      <button
        ref={triggerRef}
        type="button"
        onClick={() => setOpen(o => !o)}
        style={{
          // ─── Figma 1:1 ───────────────────────────────────
          background:     '#fff',                       // ← Figma: bg white
          borderRadius:   12,                           // ← Figma: rounded 12
          // ← [2026-05-04 핫픽스 v2] padding 14×16 → 14 24 14 20 (좌 20, 우 24 비대칭)
          // ← [2026-05-06 Admin Phase C] padding 14 24 14 20 → 12 24 12 20 (상하 14→12)
          //    + height 52 → 48 (Figma node 468:1323)
          // ← [2026-05-06 핫픽스 v3] padding 12 24 12 20 → 12 20 12 16 (좌우 각 -4, 사용자 요청)
          padding:        '12px 20px 12px 16px',        // ← 상하 12, 좌 16, 우 20
          height:         48,                           // ← Figma: h 48 (이전 52)
          gap:            6,                            // ← Figma: gap 6
          // ─── 버튼 reset ──────────────────────────────────
          border:         'none',
          cursor:         'pointer',
          display:        'flex',
          alignItems:     'center',
          justifyContent: 'center',
          overflow:       'hidden',
          fontFamily:     'inherit',
          flexShrink:     0,
          // ─── 호버 미세 효과 (Figma 외 추가) ───────────────
          transition:     'box-shadow 0.15s',
          boxShadow:      open ? '0 0 0 1.5px #111' : 'none',  // ← 열려있을 때 outline 표시
        }}>
        {/* 캘린더 아이콘 */}
        <CalendarTodayIcon size={24}/>{/* ← Figma 추출 SVG (Icons.tsx) — 기본 fill #566277 */}
        {/* 날짜 텍스트 */}
        <span style={{
          fontSize:   16,                               // ← Figma: 16
          // ← [2026-05-06 Phase 4] Figma 468:3244 'Pretendard:Regular' — fw 500 → 400
          fontWeight: 400,                              // ← Figma: Regular (이전 Medium 500)
          color:      hasValue ? '#111' : '#99A1AF',    // ← 빈 값일 땐 placeholder 회색
          lineHeight: 'normal',                         // ← Figma: leading normal
          whiteSpace: 'nowrap',
        }}>{displayDate}</span>
        {/* 요일 텍스트 (값이 있을 때만) */}
        {displayDay && (
          <span style={{
            fontSize:   16,                             // ← Figma: 16
            // ← [2026-05-06 Phase 4] Figma 468:3244 'Pretendard:Regular' — fw 500 → 400
            fontWeight: 400,                            // ← Figma: Regular (이전 Medium 500)
            // ← [2026-05-06 Admin Phase C] 색상 #99A1AF → #A9B9D5 (Figma node 468:1328)
            color:      '#A9B9D5',
            lineHeight: 'normal',
            whiteSpace: 'nowrap',
          }}>{displayDay}</span>
        )}
      </button>

      {/* ── 팝업 (open 상태에서만 마운트 — 외부 닫힘 핸들러는 popup 자체가 관리) ── */}
      {open && (
        <DatePickerPopup
          value={value}
          onChange={d => { onChange(d); setOpen(false) }}  // ← 날짜 선택 즉시 닫기
          onClose={() => setOpen(false)}
          anchorRef={triggerRef}
          min={min}
          max={max}
        />
      )}
    </>
  )
}
